const WA = 'https://wa.me/972505500632'; // the business WhatsApp number
const $ = id => document.getElementById(id);

// header hairline after the hero, mobile action bar while scrolling (hidden over the form)
const nav = document.querySelector('.nav');
const mbar = document.querySelector('.mbar');
const seen = {hero: true, contact: false};
const io = new IntersectionObserver(entries => {
  entries.forEach(e => { seen[e.target.dataset.watch] = e.isIntersecting; });
  nav.classList.toggle('scrolled', !seen.hero);
  mbar.classList.toggle('show', !seen.hero && !seen.contact);
  document.body.classList.toggle('mbar-on', !seen.hero && !seen.contact);
});
[['.hero', 'hero'], ['#contact', 'contact']].forEach(([sel, key]) => {
  const el = document.querySelector(sel);
  el.dataset.watch = key;
  io.observe(el);
});

// a space card pre-selects the place type in the form
document.querySelectorAll('.space').forEach(s => s.addEventListener('click', () => { $('f-place').value = s.dataset.place; }));

// catalog filter by collection
const chips = [...document.querySelectorAll('.chip')];
const scents = [...document.querySelectorAll('.scent')];
chips.forEach(c => c.addEventListener('click', () => {
  chips.forEach(x => x.setAttribute('aria-pressed', x === c));
  scents.forEach(s => { s.hidden = c.dataset.col !== 'all' && s.dataset.col !== c.dataset.col; });
}));

// lead form: validate, email the lead via Web3Forms, ping the business WhatsApp, open a prefilled WhatsApp message
// Public access key from web3forms.com (it is tied to the receiving inbox, not a secret).
const WEB3FORMS_KEY = 'eca6f988-880d-49a6-9322-6cf2ad8a26ff';
const form = $('lead');
const phoneOk = v => /^(?:0|\+?972)5\d{8}$|^(?:0|\+?972)[2-46-9]\d{7}$/.test(v.replace(/[\s\-()]/g, ''));
function check(input, ok) {
  input.setAttribute('aria-invalid', !ok);
  $(input.getAttribute('aria-describedby')).hidden = ok;
  return ok;
}
form.addEventListener('submit', e => {
  e.preventDefault();
  const f = form.elements, v = n => f[n].value.trim();
  const okName = check(f.name, v('name').length > 1);
  const okPhone = check(f.phone, phoneOk(v('phone')));
  if (!okName) return f.name.focus();
  if (!okPhone) return f.phone.focus();

  if (WEB3FORMS_KEY) {
    const data = new FormData(form);
    data.append('access_key', WEB3FORMS_KEY);
    data.append('subject', `פנייה חדשה מהאתר: ${v('name')}`);
    data.append('from_name', 'אתר Or Scent');
    fetch('https://api.web3forms.com/submit', {method: 'POST', body: data, keepalive: true}).catch(() => {});
  }

  const lines = [
    `שלום, אני ${v('name')}.`,
    'אשמח לקבוע פגישת התרשמות למערכת ריח.',
    `סוג המקום: ${v('place')}`,
    v('city') && `עיר: ${v('city')}`,
    `טלפון: ${v('phone')}`,
    `נוח לדבר: ${v('time')}`,
  ].filter(Boolean);
  const url = `${WA}?text=${encodeURIComponent(lines.join('\n'))}`;
  $('wa-again').href = url;
  window.open(url, '_blank', 'noopener');
  form.hidden = true;
  $('lead-done').hidden = false;
  $('lead-done').focus();
});
['name', 'phone'].forEach(n => form.elements[n].addEventListener('input', e => {
  if (e.target.getAttribute('aria-invalid') === 'true') check(e.target, n === 'name' ? e.target.value.trim().length > 1 : phoneOk(e.target.value));
}));

// accessibility widget: text size, contrast, link highlight, readable font, stop motion (remembered per browser)
(() => {
  const root = document.documentElement, btn = $('a11y-btn'), panel = $('a11y-panel');
  let st = {size: 100, contrast: false, links: false, font: false, motion: false};
  try { st = Object.assign(st, JSON.parse(localStorage.getItem('orscent-a11y') || '{}')); } catch (e) {}
  const apply = () => {
    root.style.fontSize = st.size === 100 ? '' : st.size + '%';
    $('a11y-size-val').textContent = st.size + '%';
    ['contrast', 'links', 'font', 'motion'].forEach(k => {
      root.classList.toggle('a11y-' + k, st[k]);
      const b = panel.querySelector(`[data-a11y="${k}"]`); if (b) b.setAttribute('aria-pressed', st[k]);
    });
    try { localStorage.setItem('orscent-a11y', JSON.stringify(st)); } catch (e) {}
  };
  const toggle = open => { panel.hidden = !open; btn.setAttribute('aria-expanded', open); };
  btn.addEventListener('click', () => toggle(panel.hidden));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !panel.hidden) { toggle(false); btn.focus(); } });
  document.addEventListener('click', e => { if (!panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)) toggle(false); });
  panel.addEventListener('click', e => {
    const a = e.target.closest('[data-a11y]'); if (!a) return;
    const k = a.dataset.a11y;
    if (k === 'bigger') st.size = Math.min(150, st.size + 10);
    else if (k === 'smaller') st.size = Math.max(90, st.size - 10);
    else if (k === 'reset') st = {size: 100, contrast: false, links: false, font: false, motion: false};
    else st[k] = !st[k];
    apply();
  });
  apply();
})();
